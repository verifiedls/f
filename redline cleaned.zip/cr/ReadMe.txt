1) Запустить один раз Kurome.Loader (от админа и в режиме совместимости с Windows 8)
2) Запустить Kurome.Host (от админа и держать открытым во время работы редлайна)
3) Открыть редлайн

Логин: ims0rry
Пасс: racoon

4) Открывайте свои "лучшие" тимы



1) Run Kurome.Loader once (from admin and in Windows 8 compatibility mode)
2) Run Kurome.Host (from the admin and keep open while the redline is running)
3) Open redline

Login: ims0rry
Pass: racoon

4) Unlock your "best" teams